export const productdata=[
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/6/t/z/free-sequined-embroidered-saree-granthva-fab-unstitched-original-imaggsq6b4y2adwk.jpeg?q=70",
        "title": "PRATHAM BLUE",
        "title2": "Embroidered Bollywood Georgette Saree",
        "color": "Purple",
        "selling_price": "₹789",
        "price": "₹3,999",
        "disscount": "80% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/3/j/n/free-silver-gulab-banaras-silk-palace-unstitched-original-imagz2zy2uyj6tp5.jpeg?q=70",
        "title": "Banaras silk palace",
        "title2": "Woven Banarasi Tissue Saree",
        "color": "Pink",
        "selling_price": "₹996",
        "price": "₹3,500",
        "disscount": "71% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/z/x/e/free-saree-with-georgette-fabric-sada-sobhagyavati-bhav-with-original-imagjnurkkccy8kg.jpeg?q=70",
        "title": "Qwarty",
        "title2": "Polka Print, Embroidered, Self Design Bandhani\n                          Georgett...",
        "color": "Red",
        "selling_price": "₹374",
        "price": "₹1,798",
        "disscount": "79% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/v/p/3/free-prathna-om-vastra-fab-unstitched-original-imaghmwuprfjubfn.jpeg?q=70",
        "title": "Rarebeauty",
        "title2": "Embroidered Bollywood Georgette Saree",
        "color": "Black",
        "selling_price": "₹329",
        "price": "₹2,299",
        "disscount": "85% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/s/u/t/free-matka-04-tejas-sarees-unstitched-original-imagj69c9yy4pcgh.jpeg?q=70",
        "title": "Tejassarees",
        "title2": "Embellished Bandhani Georgette Saree",
        "color": "Yellow",
        "selling_price": "₹390",
        "price": "₹942",
        "disscount": "58% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/5/z/k/free-banarasi-saree-kalapushpi-unstitched-original-imagm5vz25z6fmuj.jpeg?q=70",
        "title": "Kalapushpi",
        "title2": "Self Design Banarasi Cotton Blend, Pure Silk Saree",
        "color": "Maroon",
        "selling_price": "₹497",
        "price": "₹2,899",
        "disscount": "82% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/k7c88sw0/sari/j/z/y/free-ladli-krishna-r-fashion-original-imafphxuxmkutnt8.jpeg?q=70",
        "title": "Krishna R fashion",
        "title2": "Woven Bollywood Georgette, Cotton Silk Saree",
        "color": "Pink, Beige",
        "selling_price": "₹479",
        "price": "₹3,999",
        "disscount": "88% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/k4hcjgw0/sari/k/n/g/free-10068-h-shaibo-saree-original-imafndx6y8nqcefx.jpeg?q=70",
        "title": "Shaibo saree",
        "title2": "Checkered Bollywood Cotton Silk Saree",
        "color": "Pack of 2, Multicolor",
        "selling_price": "₹634",
        "price": "₹2,199",
        "disscount": "71% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/t/x/0/free-prathna-om-vastra-fab-unstitched-original-imag773gmebcc9md.jpeg?q=70",
        "title": "Rarebeauty",
        "title2": "Embroidered Bollywood Georgette Saree",
        "color": "Blue",
        "selling_price": "₹295",
        "price": "₹2,007",
        "disscount": "85% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/kzvlua80/sari/7/s/l/free-sds0030-sadika-unstitched-original-imagbsg4na5x3gfn.jpeg?q=70",
        "title": "MATRUCHHAYA",
        "title2": "Embroidered, Woven Daily Wear Georgette Saree",
        "color": "Grey",
        "selling_price": "₹296",
        "price": "₹1,999",
        "disscount": "85% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/g/m/i/free-60-gram-gulab-saree-adirotz-unstitched-original-imagz88maq2psggy.jpeg?q=70",
        "title": "Adirotz",
        "title2": "Embroidered Bollywood Georgette Saree",
        "color": "Magenta",
        "selling_price": "₹479",
        "price": "₹2,599",
        "disscount": "81% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/l3xcr680/sari/o/h/t/free-if-rgtg-red-pisara-unstitched-original-imagexza4cnczdzj.jpeg?q=70",
        "title": "Pisara",
        "title2": "Woven Bollywood Organza Saree",
        "color": "Multicolor",
        "selling_price": "₹1,329",
        "price": "₹4,997",
        "disscount": "73% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/w/5/n/free-pattu-saree-ejoty-fashion-unstitched-original-imag4abzywzyk5ry-bb.jpeg?q=70",
        "title": "Ejoty Fashion",
        "title2": "Floral Print Bollywood Lycra Blend Saree",
        "color": "Black",
        "selling_price": "₹289",
        "price": "₹2,999",
        "disscount": "90% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/7/i/7/free-sari-onestacreation-stitched-original-imagk7kgquderuqk.jpeg?q=70",
        "title": "ShiVAdit Ethnic",
        "title2": "Embroidered, Self Design, Applique Banarasi Art Silk,\n                          N...",
        "color": "Black",
        "selling_price": "₹649",
        "price": "₹2,499",
        "disscount": "74% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/l0zm64w0/sari/x/l/p/free-mc-50-rani-kartvya-unstitched-original-imagcnksmzyktamm.jpeg?q=70",
        "title": "Kartvya",
        "title2": "Woven Kanjivaram Jacquard, Pure Silk Saree",
        "color": "Pink",
        "selling_price": "₹373",
        "price": "₹1,699",
        "disscount": "78% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/n/5/n/free-2739s251-samah-unstitched-original-imagzj99zuqvmcg6.jpeg?q=70",
        "title": "Samah",
        "title2": "Printed, Geometric Print, Embellished Daily Wear\n                          Lycra ...",
        "color": "Black",
        "selling_price": "₹273",
        "price": "₹1,233",
        "disscount": "77% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/6/r/h/free-sequencee-blackk-radadiyatrd-unstitched-original-imagz4yqwa2vschj.jpeg?q=70",
        "title": "RadadiyaTRD",
        "title2": "Self Design Bollywood Georgette, Cotton Silk Saree",
        "color": "Black",
        "selling_price": "₹699",
        "price": "₹2,999",
        "disscount": "76% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/z/r/t/free-embellished-daily-wear-georgette-saree-black-famous-zone-original-imaghpqzthrass5u.jpeg?q=70",
        "title": "NAMRA TEX",
        "title2": "Embellished Daily Wear Georgette Saree",
        "color": "Black",
        "selling_price": "₹1,299",
        "price": "₹1,999",
        "disscount": "35% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/l1fc0i80/sari/8/b/s/free-sari-fabwoman-unstitched-original-imagcztprwg9dgvz.jpeg?q=70",
        "title": "SNH EXPORT",
        "title2": "Woven Banarasi Silk Blend Saree",
        "color": "Red",
        "selling_price": "₹499",
        "price": "₹2,999",
        "disscount": "83% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/saree-fall/l/e/2/medium-embroidered-daily-wear-art-silk-saree-yellow-angelarts-original-imag5cdh6xsfkgyy-bb.jpeg?q=70",
        "title": "Disha Fashion",
        "title2": "Embroidered Banarasi Art Silk Saree",
        "color": "Yellow",
        "selling_price": "₹478",
        "price": "₹999",
        "disscount": "52% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/ksyz8280/sari/f/j/2/free-jlk-peacock-4-pink-ab-kayimi-unstitched-original-imag6f5jkgadnhgx.jpeg?q=70",
        "title": "Kayimi",
        "title2": "Printed Bollywood Art Silk Saree",
        "color": "Pink, Beige",
        "selling_price": "₹349",
        "price": "₹1,663",
        "disscount": "79% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/x/g/i/free-fl-1199-jsitaliya-unstitched-original-imagc4q5csjac5bq-bb.jpeg?q=70",
        "title": "JSItaliya",
        "title2": "Self Design, Embroidered Bollywood Net Saree",
        "color": "White",
        "selling_price": "₹449",
        "price": "₹1,999",
        "disscount": "77% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/krkyt8w0/saree-fall/f/n/0/medium-embroidered-daily-wear-art-silk-saree-maroon-angelarts-original-imag5ccj7yfkpv5b.jpeg?q=70",
        "title": "Disha Fashion",
        "title2": "Embroidered Banarasi Art Silk Saree",
        "color": "Maroon",
        "selling_price": "₹492",
        "price": "₹999",
        "disscount": "50% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shopsy-sari/m/n/n/free-mineral-chiffon-aishwarya-unstitched-original-imaghd3e53zfgrzu.jpeg?q=70",
        "title": "Aishwarya",
        "title2": "Printed, Floral Print Daily Wear Chiffon Saree",
        "color": "Yellow",
        "selling_price": "₹449",
        "price": "₹1,999",
        "disscount": "77% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/k7xnukw0/sari/e/8/d/free-khusi-krishna-r-fashion-unstitched-original-imafq22gfteg5gzh.jpeg?q=70",
        "title": "Krishna R fashion",
        "title2": "Woven Bollywood Jacquard Saree",
        "color": "Pink, Grey",
        "selling_price": "₹469",
        "price": "₹3,999",
        "disscount": "88% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/kshtxu80/shopsy-sari/h/i/r/free-1077-red-dhnik-creation-unstitched-original-imag6fnkhgmmqzkx.jpeg?q=70",
        "title": "Rarebeauty",
        "title2": "Embroidered Bollywood Georgette Saree",
        "color": "Dark Blue",
        "selling_price": "₹349",
        "price": "₹1,999",
        "disscount": "82% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/s/g/o/free-lfs-44-cream-lasfira-unstitched-original-imagzranmgc79zn2.jpeg?q=70",
        "title": "LASFIRA",
        "title2": "Self Design Banarasi Cotton Blend, Jacquard Saree",
        "color": "Cream",
        "selling_price": "₹489",
        "price": "₹2,499",
        "disscount": "80% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/d/n/n/free-60-gram-gulab-saree-adirotz-unstitched-original-imagz88mju9uj3h7.jpeg?q=70",
        "title": "Adirotz",
        "title2": "Embroidered Bollywood Georgette Saree",
        "color": "Blue",
        "selling_price": "₹479",
        "price": "₹2,599",
        "disscount": "81% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/b/b/w/free-braso2-o-combo-lorofy-unstitched-original-imagkymbfmjbfeqj.jpeg?q=70",
        "title": "LOROFY",
        "title2": "Self Design Bollywood Net Saree",
        "color": "Red",
        "selling_price": "₹294",
        "price": "₹1,599",
        "disscount": "81% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/l4ln8nk0/sari/p/2/u/free-2535s934-samah-unstitched-original-imagfgq7pc2mc4vz.jpeg?q=70",
        "title": "Samah",
        "title2": "Printed, Geometric Print, Embellished Bhagalpuri Silk\n                          B...",
        "color": "Green, Pink",
        "selling_price": "₹289",
        "price": "₹1,563",
        "disscount": "81% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/e/a/t/free-lfs-44-light-green-lasfira-unstitched-original-imagzrarausz9jef.jpeg?q=70",
        "title": "LASFIRA",
        "title2": "Self Design Banarasi Cotton Blend, Jacquard Saree",
        "color": "Light Green",
        "selling_price": "₹471",
        "price": "₹2,499",
        "disscount": "81% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/ktep2fk0/sari/9/b/g/free-s-01-signagraph-unstitched-original-imag6raqrxtuhgkm.jpeg?q=70",
        "title": "signagraph",
        "title2": "Woven Banarasi Pure Silk, Satin Saree",
        "color": "Maroon",
        "selling_price": "₹379",
        "price": "₹3,999",
        "disscount": "90% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/krkyt8w0/sari/y/p/v/free-wedding-saree-ecolors-fab-unstitched-original-imag5c8efuhrjz9t.jpeg?q=70",
        "title": "Cartyshop",
        "title2": "Embellished Bollywood Georgette, Art Silk Saree",
        "color": "Light Blue, Blue",
        "selling_price": "₹387",
        "price": "₹3,999",
        "disscount": "90% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/kflftzk0-0/sari/o/y/c/free-hitesh2series-fumvel-unstitched-original-imafwypg4fwky3a7.jpeg?q=70",
        "title": "Jiyan Fashion Retail",
        "title2": "Floral Print Bollywood Lycra Blend Saree",
        "color": "Maroon, Black",
        "selling_price": "₹249",
        "price": "₹2,497",
        "disscount": "90% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/l3929ow0/sari/s/g/u/free-sds030-sadika-unstitched-original-imageev4hm7sxdbc.jpeg?q=70",
        "title": "MATRUCHHAYA",
        "title2": "Embroidered, Woven Daily Wear Georgette Saree",
        "color": "Yellow",
        "selling_price": "₹296",
        "price": "₹1,999",
        "disscount": "85% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/e/u/x/free-silk-samruddhi-unstitched-original-imagg9f2cagzstgz.jpeg?q=70",
        "title": "samruddhi",
        "title2": "Woven Kanjivaram Pure Silk Saree",
        "color": "Red",
        "selling_price": "₹441",
        "price": "₹5,999",
        "disscount": "92% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/ksyz8280/sari/3/h/m/free-jlk-peacock-4-red-ab-kayimi-unstitched-original-imag6f5jqghhxdpr.jpeg?q=70",
        "title": "Kayimi",
        "title2": "Printed Bollywood Art Silk Saree",
        "color": "Red, Beige",
        "selling_price": "₹349",
        "price": "₹1,663",
        "disscount": "79% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/8/9/s/free-lfs-60-light-pink-lasfira-unstitched-original-imagnas2g6yhuscx.jpeg?q=70",
        "title": "LASFIRA",
        "title2": "Self Design Banarasi Jacquard Saree",
        "color": "Pink",
        "selling_price": "₹499",
        "price": "₹2,999",
        "disscount": "83% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/kxaq7ww0/sari/o/k/q/free-grey-1692-6-kashvi-sarees-unstitched-original-imag9s7ggsjw2gcn.jpeg?q=70",
        "title": "Anand Sarees",
        "title2": "Printed, Striped Daily Wear Georgette Saree",
        "color": "White, Black",
        "selling_price": "₹299",
        "price": "₹1,299",
        "disscount": "76% off"
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/kqgyhe80/sari/z/j/t/free-greyt-1152-1-kashvi-sarees-unstitched-original-imag4h6mft9kydgv.jpeg?q=70",
        "title": "Anand Sarees",
        "title2": "Printed, Floral Print Daily Wear Georgette Saree",
        "color": "Red",
        "selling_price": "₹299",
        "price": "₹1,299",
        "disscount": "76% off"
    }
]