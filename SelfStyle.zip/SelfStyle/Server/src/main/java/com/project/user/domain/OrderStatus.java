package com.project.user.domain;

public enum OrderStatus {
	PENDING,
    PLACED,
    CONFIRMED,
    SHIPPED,
    DELIVERED,
    CANCELLED
}
