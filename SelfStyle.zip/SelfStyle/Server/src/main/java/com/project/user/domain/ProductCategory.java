package com.project.user.domain;

public enum ProductCategory {

	MALE,
	FEMALE
}
