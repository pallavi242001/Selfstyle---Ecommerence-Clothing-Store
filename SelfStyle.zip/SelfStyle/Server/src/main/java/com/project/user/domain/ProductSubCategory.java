package com.project.user.domain;

public enum ProductSubCategory {
	
	SHIRT,
	TSHIRT,
	SHOES,
	PAINT,
	SAREE,
	KURTA,
	WATCH

}
