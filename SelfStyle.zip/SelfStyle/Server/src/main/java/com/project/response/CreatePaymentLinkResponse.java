package com.project.response;

public class CreatePaymentLinkResponse {
	
	

}
