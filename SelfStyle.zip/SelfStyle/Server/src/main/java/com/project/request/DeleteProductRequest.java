package com.project.request;

public class DeleteProductRequest {
	
//	private Long 

}
